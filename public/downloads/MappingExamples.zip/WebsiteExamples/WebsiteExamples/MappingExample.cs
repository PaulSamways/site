﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebsiteExamples
{
    public class MappingExample
    {
        public class User
        {
            public User()
            {

            }
            public User(int id, string name, string email)
            {
                this.ID = id;
                this.Name = name;
                this.Email = email;
            }

            public int ID { get; set; }

            public string Name { get; set; }

            public string Email { get; set; }
        }

        public class UserDTO
        {
            public int ID { get; set; }

            public string Name { get; set; }

            public string Email { get; set; }
        }

        private const string Fmt = "ID: {0} -> {3} - Name: {1} -> {4} - Email: {2} -> {5}";

        public static void Run()
        {
            Mapping<User, UserDTO>.Configure((from, to) =>
            {
                to.ID = from.ID;
                to.Name = from.Name;
                to.Email = from.Email;
            });

            var u = new User(999, "Paul Samways", "paul@paulsamways.com");
            var dto = Mapping<User, UserDTO>.Execute(u);

            Console.WriteLine(Fmt, u.ID, u.Name, u.Email, dto.ID, dto.Name, dto.Email);

            var users = new User[] {
                new User(1, "Tom", "example@paulsamways.com"),
                new User(2, "Dick", "example@paulsamways.com"),
                new User(3, "Harry", "example@paulsamways.com")
            };
            var dtos = users
                .Select(x => Mapping<User, UserDTO>.Execute(x))
                .ToArray();

            for (var i = 0; i < users.Length; i++)
                Console.WriteLine(Fmt, users[i].ID, users[i].Name, users[i].Email, dtos[i].ID, dtos[i].Name, dtos[i].Email);

            User nUser = null;
            var nDTO = Mapping<User, UserDTO>.Execute(nUser);
            Console.WriteLine("nDTO is NULL: {0}", nDTO == null);

            try
            {
                Mapping<UserDTO, User>.Execute(dto);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
