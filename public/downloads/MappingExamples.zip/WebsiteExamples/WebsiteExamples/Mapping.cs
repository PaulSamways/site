﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebsiteExamples
{
    public static class Mapping<TFrom, TTo>
    {
        private static Action<TFrom, TTo> _map;

        public static void Configure(Action<TFrom, TTo> map)
        {
            _map = map;
        }

        public static void Execute(TFrom from, TTo to)
        {
            if (_map == null)
                throw new InvalidOperationException(
                    string.Format("No mapping has been configured for {0} -> {1}",
                        from.GetType(), to.GetType()));

            if (from != null)
            {
                if (to == null)
                    throw new ArgumentNullException("to");

                _map(from, to);
            }
        }

        public static TTo Execute(TFrom from)
        {
            if (from == null)
                return default(TTo);

            var to = Activator.CreateInstance<TTo>();
            Execute(from, to);

            return to;
        }
    }
}
